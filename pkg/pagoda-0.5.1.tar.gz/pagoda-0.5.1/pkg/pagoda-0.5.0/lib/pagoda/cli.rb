# Dir[File.join(".", "**/*.rb")].each { |f| print require f; puts f}
require 'pagoda/cli/commands'
require 'pagoda/cli/core_ext'
require 'pagoda/cli/helpers'
require 'pagoda/cli/helpers/base'

module Pagoda
  module CLI

  end
end
