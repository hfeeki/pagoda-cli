module Pagoda
  module CLI
    VERSION = "0.5.1"
  end
end
