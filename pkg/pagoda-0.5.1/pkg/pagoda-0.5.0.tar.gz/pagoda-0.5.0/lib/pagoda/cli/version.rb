module Pagoda
  module CLI
    VERSION = "0.5.0"
  end
end
